
public class MethodCalls {

	public MethodCalls() {
		// TODO Auto-generated constructor stub
	}

}
