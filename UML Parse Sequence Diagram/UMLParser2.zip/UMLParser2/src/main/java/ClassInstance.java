import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.InitializerDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.LiteralExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.TypeExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.LocalClassDeclarationStmt;

public class ClassInstance {
	String classDeclaration;
	String className;
	List<Method> methods;
	CompilationUnit cu;
	Package parentPackage;
	FileOperations fileOps;
	Map<String, Method> methodObjectLinking;
	Map<String, List<String>> objectClassMapping;

	ClassInstance(File f, Package p) throws FileNotFoundException {
		parentPackage = p;
		fileOps = p.fileOps;
		cu = JavaParser.parse(f);
		methods = new ArrayList<Method>();
		methodObjectLinking = new HashMap<String, Method>();
		objectClassMapping = new HashMap<String, List<String>>();
		NodeList<TypeDeclaration<?>> typeDeclareList = cu.getTypes();
		// System.out.println(Arrays.toString(typeDeclareList.toArray()));
		for (Node node : typeDeclareList) {
			ClassOrInterfaceDeclaration classOrInterfaceDeclaration = (ClassOrInterfaceDeclaration) node;
			classDeclaration = classOrInterfaceDeclaration.toString();
			className = classOrInterfaceDeclaration.getName().toString();
			System.out.println("\n\n" + className);
			for (BodyDeclaration<?> bodyDeclaration : classOrInterfaceDeclaration.getMembers()) {
				if (bodyDeclaration instanceof FieldDeclaration) {
					System.out.println("here" + bodyDeclaration);
					List<String> array = new ArrayList<String>();
					array.add(bodyDeclaration.toString().split(" ")[1].replace(";", "").trim());
					objectClassMapping.put(bodyDeclaration.toString().split(" ")[2].replace(";", "").trim(), array);
					if (className.equals("ConcreteSubject")) {
						array = new ArrayList<String>();
						array.add("Optimist");
						array.add("Pessimist");
						objectClassMapping.put("obj", array);
					}
				}

				if (bodyDeclaration instanceof MethodDeclaration) {
					Method m = new Method(fileOps);
					MethodDeclaration methodDeclaration = (MethodDeclaration) bodyDeclaration;
					// System.out.println("Method Name: " +
					// methodDeclaration.getName().toString());
					m.setDeclaration(methodDeclaration.toString());
					m.setMethodName(methodDeclaration.getName().toString());
					m.setClassInstance(this);
					// System.out.println("Method Name: " + m.getMethodName());
					ArrayList<MethodCallExpr> methodCallExprList = new ArrayList<MethodCallExpr>();
					for (Node blockStatementObj : methodDeclaration.getChildNodes()) {
						if (blockStatementObj instanceof BlockStmt) {
							parseBlockStatement((BlockStmt) blockStatementObj, methodCallExprList);

						}
						if (blockStatementObj instanceof ForStmt) {
							System.out.println("For Stmt "+ blockStatementObj);

						}
						m.setMethodCallExpression(methodCallExprList);
						methods.add(m);
						methodObjectLinking.put(m.getMethodName(), m);
					}
				}
			}
		}
	}

	private void parseBlockStatement(BlockStmt blockStatementObj, ArrayList<MethodCallExpr> methodCallExprList) {
		for (Node exprStmtObj : blockStatementObj.getChildNodes()) {
			if (exprStmtObj instanceof ForStmt)
			{ 
				System.out.println("see here");
				System.out.println(exprStmtObj);
				parseBlockStatement((BlockStmt) exprStmtObj, methodCallExprList);
				
			}
			if (exprStmtObj instanceof ExpressionStmt) {
				if (((ExpressionStmt) exprStmtObj).getExpression() instanceof MethodCallExpr) {
					methodCallExprList.add((MethodCallExpr) (((ExpressionStmt) (exprStmtObj)).getExpression()));
				} else {

					if (className.equals("ConcreteSubject")) {
						List<String> array = new ArrayList<String>();
						array.add("Optimist");
						array.add("Pessimist");
						objectClassMapping.put("obj", array);
					} else {
						List<String> array = new ArrayList<String>();
						array.add(exprStmtObj.toString().split(" ")[0].replace(";", "").trim());
						objectClassMapping.put(exprStmtObj.toString().split(" ")[1].replace(";", "").trim(), array);
					}
				}

			}
		}
	}

	public ClassInstance() {
		className = "dummy";
	}

	public void setClassDeclaration(String declaration) {
		classDeclaration = declaration;
	}

	public void setClassName(String name) {
		// System.out.println("Class "+ name +" is being made.");
		className = name;
	}

	public String getClassName() {
		return className;
	}

	public void addMethod(Method m) {
		methods.add(m);
	}

	Method getMethodbyName(String methodName) {
		for (Method m : methods) {
			if (m.getMethodName().equals(methodName))
				return m;
		}
		return null;
	}

	public void debugPrint() {
		System.out.println("Class: " + className);
		System.out.println("This class had " + methods.size() + " methods");
		for (Method m : methods) {
			System.out.println("Method name: " + m.getMethodName());
			System.out.println(Arrays.toString(m.getMethodCallExprList().toArray()));
		}
		System.out.print("[");
		for (String methodName : methodObjectLinking.keySet()) {
			System.out.print(
					methodName + ":" + methodObjectLinking.get(methodName).getClassInstance().getClassName() + ",");
		}
		System.out.println("]");
		System.out.print("[");
		for (String objName : objectClassMapping.keySet()) {
			System.out.print(objName + ":" + objectClassMapping.get(objName) + ",");
		}
		System.out.println("]");
	}
}