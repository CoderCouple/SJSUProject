import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;

public class Method {
	FileOperations f;
	ClassInstance parentClass;
	String methodDeclaration;
	String methodName;
	List<MethodCallExpr> calls = new ArrayList<MethodCallExpr>();
	boolean flag = true;

	public Method(FileOperations file) {
		f = file;
	}

	public void setClassInstance(ClassInstance classIns) {
		parentClass = classIns;
	}

	public ClassInstance getClassInstance() {
		return parentClass;
	}

	public void setDeclaration(String declarationAsString) {
		methodDeclaration = declarationAsString;
	}

	public void setMethodName(String declarationAsString) {
		methodName = declarationAsString;
	}

	public String getMethodName() {
		return methodName;
	}

	public List<MethodCallExpr> getMethodCallExprList() {
		return calls;
	}

	public void setMethodCallExpression(List<MethodCallExpr> methodCallExpression) {
		calls = methodCallExpression;
	}

	public void writeScript() throws IOException {

		System.out.println("WriteScript for method " + methodName);

		for (MethodCallExpr methodCallExpr : calls) {
			
			ClassInstance callerClass = parentClass;
			String displayCallerClassName = parentClass.getClassName();
			String calleeFunction = methodCallExpr.getName().toString();
			
			List<String> calleeClassNames = new ArrayList<String>();
			calleeClassNames.add(parentClass.getClassName());
			List<String> displayCalleeClassNames = new ArrayList<String>();
			displayCalleeClassNames.add(calleeClassNames.get(0));
			List<ClassInstance> calleeClasses = new ArrayList<ClassInstance>();
			calleeClasses.add(parentClass);
			
			
			if (methodCallExpr.toString().indexOf(".") != -1) {
				displayCalleeClassNames = new ArrayList<String>();
				calleeClassNames = new ArrayList<String>();
				calleeClasses =  new ArrayList<ClassInstance>();
				String calleeObject = methodCallExpr.toString().substring(0, methodCallExpr.toString().indexOf("."));
				System.out.println("The callee object is " + calleeObject);
				if (calleeObject.equals("System"))
					continue;
				calleeClassNames.addAll(parentClass.objectClassMapping.get(calleeObject));
				for (String className : calleeClassNames)
				{
					ClassInstance getClass = parentClass.parentPackage.getClassByName(className);
					if(getClass!=null)
						calleeClasses.add(getClass);
					else
						calleeClasses.add(new ClassInstance());
				}
				displayCalleeClassNames.addAll(calleeClassNames);

			}
			if (!(calleeClasses.isEmpty() && calleeClasses.isEmpty())) {
				for (int i = 0; i < calleeClasses.size(); i++) {
					System.out.println(i);
					String calleeClassName = calleeClassNames.get(i);
					String displayCalleeClassName = displayCalleeClassNames.get(i);
					ClassInstance calleeClass = calleeClasses.get(i);

					if (calleeClassName.equals("ConcreteSubject")) {
						displayCalleeClassName = "TheEconomy";
					} 
					

					if (callerClass.getClassName().equals("ConcreteSubject")) {
						displayCallerClassName = "TheEconomy";
					} 

					// System.out.println(methodCallExpr);

					if (!calleeClass.getClassName().equals("dummy")) {
						// System.out.println(calleeClass.getClassName());
						Method calleeMethod = parentClass.getMethodbyName(calleeFunction);

						ClassInstance parentCallee = calleeClass;

						System.out.println("The callee class name is " + calleeClass.getClassName());
						if (calleeMethod == null) {
							if (calleeClassName.equals("TheEconomy")) {
								calleeMethod = parentClass.parentPackage.getClassByName("ConcreteSubject")
										.getMethodbyName(calleeFunction);
								parentCallee = parentClass.parentPackage.getClassByName("ConcreteSubject");
							} else if ((calleeClassName.equals("Pessimist") || calleeClassName.equals("Optimist")) && !calleeFunction.equals("update")) {
								calleeMethod = parentClass.parentPackage.getClassByName("ConcreteObserver")
										.getMethodbyName(calleeFunction);
								parentCallee = parentClass.parentPackage.getClassByName("ConcreteObserver");
							}

						}

						System.out.println("The caller class is " + parentCallee.getClassName());
						if (parentCallee.methods.contains(calleeMethod)) {
							f.writeToFileContent(displayCallerClassName + " -> " + displayCalleeClassName + " : "
									+ methodCallExpr.toString() + "\n" + "activate " + displayCalleeClassName + "\n");
							System.out.println(displayCallerClassName + " -> " + displayCalleeClassName + " : "
									+ methodCallExpr.toString() + "\n" + "activate " + displayCalleeClassName + "\n");
							calleeMethod.writeScript();
							f.writeToFileContent(displayCalleeClassName + " -->> " + displayCallerClassName + "\n"
									+ "deactivate " + displayCalleeClassName + "\n");
							System.out.println(displayCalleeClassName + " -->> " + displayCallerClassName + "\n"
									+ "deactivate " + displayCalleeClassName + "\n");
						}
					}
				}
			}
		}
	}
}
