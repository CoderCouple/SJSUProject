import java.util.List;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;

import net.sourceforge.plantuml.FileFormat;
import net.sourceforge.plantuml.FileFormatOption;
import net.sourceforge.plantuml.GeneratedImage;
import net.sourceforge.plantuml.SourceFileReader;
import net.sourceforge.plantuml.SourceStringReader;

public class MainRun {

	// Folder Structure for running the project on LINUX OS

	// Setting Up the local directory structure for reading the source JAVA
	// files (SOURCE_FILE_PATH) and also placing the generated JAVA output files (TARGET_FILE_PATH)
	
	 //public static final String OS_HOME = "/home/sunil28";
	 public static final String OS_HOME = "/home/sunil28";
	 public static final String SOURCE_FILE_PATH = OS_HOME + "/" + "UML_Test";
	 public static final String TARGET_FILE_PATH = OS_HOME + "/" + "UML_Test"+ "/" + "UML_Test_Output";
	 public static final String TARGET_JAVA_FILE = "MyUMLOutput.java";
	 public static final String TARGET_PNG_FILE = "MyUMLOutput.png";
	 public static final String TARGET_JAVA_FILE_ACCESS = TARGET_FILE_PATH +"/" + TARGET_JAVA_FILE;
	 public static final String TARGET_PNG_FILE_ACCESS = TARGET_FILE_PATH +"/" + TARGET_PNG_FILE;

	// Folder Structure for running the project on WINDOWS OS

	// Setting Up the local directory structure for reading the source JAVA
	// files (SOURCE_FILE_PATH) and also placing the generated JAVA output files (TARGET_FILE_PATH)
	//public static final String OS_HOME = "C:\\Users\\admin\\Desktop\\UMLGraph-5.7_2.32-SNAPSHOT";
	//public static final String SOURCE_FILE_PATH = OS_HOME + "\\" + "UML_Test";
	//public static final String TARGET_FILE_PATH = OS_HOME + "\\" + "UML_Test" + "\\" + "UML_Test_Output";
	//public static final String TARGET_JAVA_FILE = "MyUMLOutput.java";
	//public static final String TARGET_PNG_FILE = "MyUMLOutput.png";
	//public static final String TARGET_JAVA_FILE_ACCESS = TARGET_FILE_PATH + "\\" + TARGET_JAVA_FILE;
	//public static final String TARGET_PNG_FILE_ACCESS = TARGET_FILE_PATH + "\\" + TARGET_PNG_FILE;

	// Array list to hold the list of all the classes,methods and attributes present in the the source directory
	public static ArrayList<String> FileListAccess = new ArrayList<String>();
	public static ArrayList<ClassInstance> ClassList = new ArrayList<ClassInstance>();

	public static void main(String[] args) throws IOException{
		FileOperations fJava = new FileOperations(TARGET_JAVA_FILE_ACCESS);
		try {
			Package p = new Package();
			fJava.deleteFile();
			FileOperations fPng = new FileOperations(TARGET_PNG_FILE_ACCESS);
			fPng.deleteFile();
			p.assignClassList(SOURCE_FILE_PATH, fJava);
			p.debugPrint();
			
			FileOperations fOutput = new FileOperations(TARGET_JAVA_FILE_ACCESS);
			p.writeScript("main","Main");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		File source = new File(TARGET_JAVA_FILE_ACCESS);
		SourceFileReader reader = new SourceFileReader(source);
		List<GeneratedImage> list = reader.getGeneratedImages();
		File png = list.get(0).getPngFile();
		
	}

}

