import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Package {
    List<ClassInstance> classList;
    
    FileOperations fileOps;
	
    void assignClassList (String SOURCE_FILE_PATH, FileOperations fJava) 
	{
		try
		{
			fileOps=fJava;
			classList = new ArrayList<ClassInstance>();
			
			File ImportFile = new File(SOURCE_FILE_PATH);
			for (final File child : ImportFile.listFiles()) {
	
				if (!child.isDirectory() && child.getName().contains(".java")) {
					System.out.println("File "+child.getName()+" is being opened");
					ClassInstance newClass = new ClassInstance(child, this);
					System.out.println("class "+newClass.getClassName()+" is made");
					classList.add(newClass);
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
    ClassInstance getClassByName(String searchName)
	{
		for(ClassInstance classIns : classList)
		{
			if(classIns.getClassName().equals(searchName))
				return classIns;
		}
		return null;
	}
	
    public void debugPrint() throws IOException
	{
    	
		for(ClassInstance c: classList)
		{
			c.debugPrint();
		}
		
	}

    public void writeScript(String functionName, String className) throws IOException
    {
    	fileOps.writeToFileContent("@startuml");
    	Method firstMethod = getClassByName(className).methodObjectLinking.get(functionName);
    	firstMethod.writeScript();
    	fileOps.writeToFileContent("@enduml");
    }
}
